# Jak zbudować samodzielny APK (Python działa wewnątrz aplikacji)

Co zostało zrobione: backend Flask + cały silnik gry (`football_engine`)
i frontend są teraz spięte przez **Chaquopy** — bibliotekę, która wbudowuje
prawdziwy interpreter Pythona do APK. Gracz instaluje appkę z Google Play,
odpala ikonkę i gra offline — bez Render, bez internetu, bez konfigurowania
czegokolwiek.

Jak to działa: `MainActivity.java` przy starcie appki uruchamia Pythona
(Chaquopy) w tle, który odpala serwer Flask na `127.0.0.1:5000` wewnątrz
telefonu. Gdy serwer odpowie, WebView przełącza się na tego lokalnego
"serwera". Zapisy gry trafiają do prywatnego katalogu appki (`filesDir`),
więc zostają na telefonie między sesjami.

## Czego potrzebujesz (jednorazowo, na komputerze)

- **Android Studio** (najnowsza wersja) — https://developer.android.com/studio
- Połączenie z internetem **podczas pierwszego builda** — Gradle musi pobrać
  plugin Chaquopy i dystrybucję Pythona dla wybranych architektur (ARM/x86).
  Po pierwszym pobraniu kolejne buildy mogą działać offline (cache Gradle).

## Kroki

1. Otwórz folder `android/` w Android Studio (File → Open).
2. Poczekaj aż Gradle zsynchronizuje projekt (pobierze m.in. Chaquopy).
3. Podłącz telefon (USB, tryb dewelopera + debugowanie USB) albo użyj emulatora.
4. Kliknij Run ▶ — albo z terminala w folderze `android/`:
   ```
   ./gradlew assembleDebug
   ```
   Gotowy plik: `android/app/build/outputs/apk/debug/app-debug.apk`

## Publikacja w Google Play

Do publikacji potrzebny jest **podpisany build release**, nie debug:

```
./gradlew bundleRelease
```

To wygeneruje plik `.aab` (Android App Bundle) w
`android/app/build/outputs/bundle/release/` — to właśnie ten format
wymaga Google Play Console. Będziesz musiał:

1. Wygenerować keystore do podpisywania (`keytool -genkey ...` albo
   przez Android Studio: Build → Generate Signed Bundle/APK).
2. Skonfigurować `signingConfigs` w `android/app/build.gradle`.
3. Założyć konto dewelopera Google Play (jednorazowa opłata) i wypełnić
   kartę aplikacji (opis, screenshoty, polityka prywatności itd.).

To już czysto administracyjne kroki Google, niezwiązane z kodem —
mogę pomóc przygotować politykę prywatności albo opis aplikacji, jeśli
będziesz tego potrzebować.

## Uwaga o rozmiarze

Chaquopy dokłada do APK interpreter Pythona dla każdej architektury
(~15–25 MB na architekturę). W `android/app/build.gradle` w bloku
`ndk { abiFilters ... }` są ustawione `armeabi-v7a`, `arm64-v8a`,
`x86_64` — to pokrywa niemal wszystkie telefony. Jeśli zależy Ci na
mniejszym APK, możesz zostawić tylko `arm64-v8a` (obejmuje zdecydowaną
większość telefonów z ostatnich ~8 lat), albo użyć Android App Bundle
(.aab) — Google Play i tak dostarczy każdemu urządzeniu tylko
pasującą architekturę.

## Co jeśli coś nie zbuduje się za pierwszym razem

Najczęstszy problem to brak internetu przy pierwszym Gradle sync
(Chaquopy pobiera Python przy pierwszej konfiguracji) — upewnij się,
że komputer ma wtedy działające połączenie.
