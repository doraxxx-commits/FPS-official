"""
Punkt wejścia dla Chaquopy.
Wywoływany z MainActivity: Python.getInstance().getModule("main").callAttr("start", filesDir)
Uruchamia serwer Flask lokalnie na 127.0.0.1, dane zapisu trafiają do filesDir aplikacji.
"""
from backend.app import run_server


def start(user_data_dir):
    run_server(host="127.0.0.1", port=5000, user_data_dir=user_data_dir)
