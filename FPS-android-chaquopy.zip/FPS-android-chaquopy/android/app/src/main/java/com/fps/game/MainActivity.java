package com.fps.game;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import com.getcapacitor.BridgeActivity;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Uruchamia lokalny serwer Flask (przez Chaquopy) w tle, a po jego starcie
 * przełącza WebView z domyślnej strony startowej na http://127.0.0.1:5000,
 * gdzie backend serwuje już cały frontend. Gra działa w pełni offline —
 * jedyne co robi ten serwer to obsługa lokalnego API i zapisów, bez
 * łączenia się z internetem ani z Render.
 */
public class MainActivity extends BridgeActivity {

    private static final String TAG = "FPS-Python";
    private static final String LOCAL_SERVER_URL = "http://127.0.0.1:5000/";
    private static final String HEALTH_URL = "http://127.0.0.1:5000/api/health";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        startPythonServer();
        waitForServerThenLoad();
    }

    private void startPythonServer() {
        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }
        final Python py = Python.getInstance();
        final String filesDir = getFilesDir().getAbsolutePath();

        new Thread(() -> {
            try {
                PyObject mainModule = py.getModule("main");
                mainModule.callAttr("start", filesDir);
            } catch (Exception e) {
                Log.e(TAG, "Błąd uruchamiania serwera Flask", e);
            }
        }, "python-flask-server").start();
    }

    private void waitForServerThenLoad() {
        new Thread(() -> {
            boolean ready = false;
            for (int i = 0; i < 100; i++) { // do ~20s prób co 200ms
                if (isServerUp()) {
                    ready = true;
                    break;
                }
                try {
                    Thread.sleep(200);
                } catch (InterruptedException ignored) {
                }
            }
            final boolean finalReady = ready;
            new Handler(Looper.getMainLooper()).post(() -> {
                if (finalReady && getBridge() != null && getBridge().getWebView() != null) {
                    getBridge().getWebView().loadUrl(LOCAL_SERVER_URL);
                } else {
                    Log.e(TAG, "Serwer Flask nie odpowiedział w oczekiwanym czasie.");
                }
            });
        }, "python-health-check").start();
    }

    private boolean isServerUp() {
        try {
            URL url = new URL(HEALTH_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(300);
            conn.setReadTimeout(300);
            int code = conn.getResponseCode();
            conn.disconnect();
            return code == 200;
        } catch (IOException e) {
            return false;
        }
    }
}
